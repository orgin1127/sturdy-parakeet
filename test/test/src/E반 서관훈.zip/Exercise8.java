package test;

public class Exercise8 {

	public static void main(String[] args) {
		Student s = new Student("ȫ�浿", 1, 1, 100, 60, 76);
		System.out.println("�̸�:"+s.getName());
		System.out.println("����:"+s.getTotal());
		System.out.println("���:"+s.getAverage());
	}

}
