package test;

public class Exercise1 {

	public static void main(String[] args) {
		int num = 333;
		
		int num2 = (num/10)*10;
		System.out.println(num2+1);
	}

}
